// PSX Terminal API - Search for symbols and get real-time data
export async function GET(request) {
  try {
    const url = new URL(request.url);
    const query = url.searchParams.get('q') || '';
    const limit = url.searchParams.get('limit') || '10';

    if (!query || query.length < 1) {
      return Response.json({
        success: false,
        message: 'Search query is required',
        data: []
      });
    }

    // First get all available symbols
    const symbolsResponse = await fetch('https://psxterminal.com/api/symbols', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'PSX-Capitals-App/1.0'
      }
    });

    if (!symbolsResponse.ok) {
      throw new Error('Failed to fetch symbols');
    }

    const symbolsData = await symbolsResponse.json();
    
    if (!symbolsData.success || !symbolsData.data) {
      throw new Error('Invalid symbols response');
    }

    // Filter symbols based on search query
    const filteredSymbols = symbolsData.data.filter(symbol => 
      symbol.toLowerCase().includes(query.toLowerCase())
    ).slice(0, parseInt(limit));

    // Get real-time data for filtered symbols
    const searchResults = await Promise.all(
      filteredSymbols.map(async (symbol) => {
        try {
          const tickerResponse = await fetch(`https://psxterminal.com/api/ticks/REG/${symbol}`, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'User-Agent': 'PSX-Capitals-App/1.0'
            }
          });

          if (tickerResponse.ok) {
            const tickerData = await tickerResponse.json();
            if (tickerData.success && tickerData.data) {
              return {
                symbol: tickerData.data.symbol,
                price: tickerData.data.price,
                change: tickerData.data.change,
                changePercent: tickerData.data.changePercent,
                volume: tickerData.data.volume,
                market: tickerData.data.market,
                marketState: tickerData.data.st,
                timestamp: tickerData.data.timestamp
              };
            }
          }
          
          // Return basic symbol if ticker data unavailable
          return {
            symbol: symbol,
            price: null,
            change: null,
            changePercent: null,
            volume: null,
            market: 'REG',
            marketState: 'UNKNOWN',
            timestamp: Date.now()
          };
        } catch (error) {
          console.error(`Error fetching data for ${symbol}:`, error);
          return {
            symbol: symbol,
            price: null,
            change: null,
            changePercent: null,
            volume: null,
            market: 'REG',
            marketState: 'ERROR',
            timestamp: Date.now()
          };
        }
      })
    );

    return Response.json({
      success: true,
      data: searchResults,
      query: query,
      count: searchResults.length,
      timestamp: Date.now()
    });

  } catch (error) {
    console.error('Error in PSX search:', error);
    
    // Fallback search results
    const query = new URL(request.url).searchParams.get('q') || '';
    const fallbackSymbols = [
      'KTM', 'HBL', 'ENGRO', 'LUCK', 'OGDC', 'PPL', 'SSGC', 'TRG', 
      'UBL', 'MCB', 'ABL', 'FFC', 'MARI', 'HUBC', 'POL', 'NESTLE'
    ];
    
    const filteredFallback = fallbackSymbols
      .filter(symbol => symbol.toLowerCase().includes(query.toLowerCase()))
      .slice(0, 10)
      .map(symbol => ({
        symbol: symbol,
        price: Math.random() * 500 + 100,
        change: (Math.random() - 0.5) * 20,
        changePercent: (Math.random() - 0.5) * 10,
        volume: Math.floor(Math.random() * 10000000),
        market: 'REG',
        marketState: 'FALLBACK',
        timestamp: Date.now()
      }));

    return Response.json({
      success: true,
      data: filteredFallback,
      query: query,
      count: filteredFallback.length,
      timestamp: Date.now(),
      fallback: true
    });
  }
}